package utils;

public class Constant {
	public static final String FILEPATH = System.getProperty("user.dir")+"\\excel\\data.xlsx";
	
	public static final String Add_FILEPATH = System.getProperty("user.dir")+"\\excel\\address.xlsx";
	
	public static final String Prod_FILEPATH = System.getProperty("user.dir")+"\\excel\\product.xlsx";
	
	

}
